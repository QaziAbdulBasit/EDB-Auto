<div class="content d-flex flex-column flex-column-fluid" id="kt_content">

</div>
